#include <iostream>
#include <fstream>
#include <vector>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <cmath>
#include <limits>
#include <string>
#include <stb/stb_image.h>
#include <stb/stb_image_write.h>
#include <algorithm>

using namespace glm;
using namespace std;

#define WIDTH 800
#define HEIGHT 800
#define INPUT_FILE_PATH "res/textures/scene1.txt"

struct Ray {
    vec3 origin;
    vec3 direction;

    Ray(const vec3& origin, const vec3& direction)
        : origin(origin), direction(normalize(direction)) {}

    vec3 pointAtParameter(float t) const {
        return origin + t * direction;
    }
};

struct Material {
    vec3 color;
    float shininess;

    Material(const vec3& color = vec3(1.0f), float shininess = 0.0f)
        : color(color), shininess(shininess) {}
};

struct Object {
    Material material;
    int status; // 0: regular, 1: reflective, 2: transparent

    virtual bool intersect(const Ray& ray, float& t) = 0;
    virtual vec3 getNormal(const vec3& point) const = 0;
    void setColor(const vec3& newColor) {
        material.color = newColor;
    }
    virtual ~Object() {}
};

struct Sphere : public Object {
    vec3 center;
    float radius;

    Sphere(const vec3& center, float radius, const Material& material, int status) {
        this->center = center;
        this->radius = radius;
        this->material = material;
        this->status = status;
    }

    bool intersect(const Ray& ray, float& t) override {
        vec3 oc = ray.origin - center;
        float a = dot(ray.direction, ray.direction);
        float b = 2.0f * dot(oc, ray.direction);
        float c = dot(oc, oc) - radius * radius;
        float discriminant = b * b - 4 * a * c;

        if (discriminant < 0) return false;

        float sqrtDiscriminant = sqrt(discriminant);
        float t1 = (-b - sqrtDiscriminant) / (2.0f * a);
        float t2 = (-b + sqrtDiscriminant) / (2.0f * a);

        if (t1 > 1e-4) {
            t = t1;
            return true;
        }
        if (t2 > 1e-4) {
            t = t2;
            return true;
        }
        return false;
    }

    vec3 getNormal(const vec3& point) const override {
        return normalize(point - center);
    }
};

struct Plane : public Object {
    vec3 normal;
    float d;

    Plane(const vec3& normal, float d, const Material& material, int status) {
        this->normal = normal;
        this->d = d;
        this->material = material;
        this->status = status;
    }

    bool intersect(const Ray& ray, float& t) override {
        float denominator = dot(normal, ray.direction);
        if (abs(denominator) < 1e-6) return false;

        t = -(dot(normal, ray.origin) + d) / denominator;
        return t > 1e-4;
    }

    vec3 getNormal(const vec3& point) const override {
        return normalize(normal);
    }

    vec3 checkerboardColor(vec3 rgbColor, vec3 hitPoint) {
 // Checkerboard pattern
 float scaleParameter = 0.5f;
 float checkerboard = 0;
 if (hitPoint.x < 0) {
 checkerboard += floor((0.5-hitPoint.x) / scaleParameter);
 }
 else {
 checkerboard += floor(hitPoint.x / scaleParameter);
 }
 if (hitPoint.y < 0) {
 checkerboard += floor((0.5-hitPoint.y) / scaleParameter);
 }
 else {
 checkerboard += floor(hitPoint.y / scaleParameter);
 }
 checkerboard = (checkerboard * 0.5)-int(checkerboard * 0.5);
 checkerboard *= 2;
 if (checkerboard > 0.5) {
 return 0.5f * rgbColor;
 }
 return rgbColor;
 }

};


struct Light {
    vec3 position;
    vec3 intensity;

    Light(const vec3& position, const vec3& intensity)
        : position(position), intensity(intensity) {}

    virtual ~Light() {}
};

struct DirectionalLight : public Light {
    vec3 direction;

    DirectionalLight(const vec3& dir, const vec3& intensity)
        : Light(vec3(0.0f), intensity), direction(normalize(dir)) {}
};

struct Spotlight : public Light {
    vec3 direction;
    float cutoffCos;

    Spotlight(const vec3& pos, const vec3& dir, float cutoffCos, const vec3& intensity)
        : Light(pos, intensity), direction(normalize(dir)), cutoffCos(cutoffCos) {}
};

bool isInShadow(const vec3& point, const Light& light, const vector<Object*>& objects, const Object* currentObject) {
    vec3 lightDir;
    float maxDistance = numeric_limits<float>::infinity();

    // Determine the direction and maximum distance for the light
    if (auto dirLight = dynamic_cast<const DirectionalLight*>(&light)) {
        lightDir = normalize(-dirLight->direction);
    } else if (auto spotLight = dynamic_cast<const Spotlight*>(&light)) {
        lightDir = normalize(spotLight->position - point);
        maxDistance = length(spotLight->position - point);

        // Check if point is outside the spotlight cutoff angle
        if (dot(lightDir, normalize(spotLight->direction)) < spotLight->cutoffCos) {
            return true; // Point is outside the spotlight beam
        }
    } else { // Point light
        lightDir = normalize(light.position - point);
        maxDistance = length(light.position - point);
    }

    // Create a shadow ray
    Ray shadowRay(point + lightDir * 1e-4f, lightDir);

    // Check for intersection with other objects
    for (const auto& object : objects) {
        if (object == currentObject) continue; // Ignore the current object

        float t;
        if (object->intersect(shadowRay, t) && t < maxDistance) {
            return true; // Shadow ray hits an object before reaching the light
        }
    }

    return false; // No shadow
}



vec3 calculateLighting(const vec3& point, const vec3& normal, const vec3& viewDir,
                       const Material& material, const vector<Light*>& lights,
                       const vector<Object*>& objects, const Object* currentObject) {
    vec3 I = vec3(0.0f);

    // Ambient component
    vec3 ambient = vec3(0.1f) * material.color;
    I += ambient;

    for (const auto& light : lights) {
        vec3 lightDir;
        vec3 lightIntensity;

        // Determine light direction and intensity
        if (auto dirLight = dynamic_cast<DirectionalLight*>(light)) {
            lightDir = normalize(-dirLight->direction);
            lightIntensity = dirLight->intensity;
        } else if (auto spotLight = dynamic_cast<Spotlight*>(light)) {
            lightDir = normalize(spotLight->position - point);
            lightIntensity = spotLight->intensity;

            // Check if the point is outside the spotlight cutoff angle
            if (dot(lightDir, normalize(spotLight->direction)) < spotLight->cutoffCos) {
                continue; // Skip this light
            }
        } else {
            lightDir = normalize(light->position - point);
            lightIntensity = light->intensity;
        }

        // Shadow term
        float S_i = isInShadow(point, *light, objects, currentObject) ? 0.0f : 1.0f;

        // Diffuse component
        float N_dot_L = std::max(dot(normal, lightDir), 0.0f);
        vec3 diffuse = S_i * material.color * lightIntensity * N_dot_L;

        // Specular component
        vec3 reflectDir = reflect(-lightDir, normal);
        float R_dot_V = std::max(dot(viewDir, reflectDir), 0.0f);
        vec3 specular = vec3(0.0f);
        if (R_dot_V > 0.0f) {
            float specularIntensity = 0.2f; // Reduced specular intensity
            specular = S_i * lightIntensity * pow(R_dot_V, std::min(material.shininess, 50.0f)) * specularIntensity;
        }

        I += diffuse + specular;
    }

    return I;
}



vec3 traceRay(const Ray& ray, const vector<Object*>& objects, const vector<Light*>& lights, int depth) {
    if (depth > 5) return vec3(0.0f);

    Object* closestObject = nullptr;
    float closestT = numeric_limits<float>::infinity();
    vec3 hitPoint, normal;

    for (const auto& object : objects) {
        float t = 0.0f;
        if (object->intersect(ray, t) && t < closestT) {
            closestT = t;
            closestObject = object;
        }
    }

if (!closestObject) return vec3(0.0f, 0.0f, 0.0f);

    hitPoint = ray.pointAtParameter(closestT);
    normal = closestObject->getNormal(hitPoint);
    vec3 viewDir = normalize(-ray.direction);

   if (Plane* plane = dynamic_cast<Plane*>(closestObject)) {
    // Get the checkerboard color at the intersection point
    vec3 checkerColor = plane->checkerboardColor(plane->material.color,hitPoint);

    // Use the checkerboard color as the material color
    return calculateLighting(hitPoint, normal, viewDir, Material(checkerColor, plane->material.shininess), lights, objects, closestObject);
}


    if (closestObject->status == 1) {
        vec3 reflectedDir = reflect(ray.direction, normal);
        Ray reflectedRay(hitPoint + normal * 1e-4f, reflectedDir);
        vec3 recursiveColor = traceRay(reflectedRay, objects, lights, depth + 1);
        return calculateLighting(hitPoint, normal, viewDir,
                                                 closestObject->material, lights, 
                                                 objects, closestObject);
    }

    if (closestObject->status == 2) {
        float eta = 1.0f / 1.5f;
        vec3 refractedDir = refract(ray.direction, normal, eta);

        if (length(refractedDir) > 0.0f) {
            Ray refractedRay(hitPoint - normal * 1e-4f, refractedDir);
            vec3 recursiveColor = traceRay(refractedRay, objects, lights, depth + 1);
            return calculateLighting(hitPoint, normal, viewDir,
                                                 closestObject->material, lights, 
                                                 objects, closestObject);
        }
    }

    return calculateLighting(hitPoint, normal, viewDir,
                                                 closestObject->material, lights, 
                                                 objects, closestObject);
}

void parseScene(const string& filename, vector<Object*>& objects, vector<Light*>& lights, vec3& cameraPos, vec3& ambientLight) {
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Error: Could not open scene file." << endl;
        exit(1);
    }

    string type;
    Material currentMaterial(vec3(1.0f), 0.0f);
    vector<vec3> spotlightPositions;
    vector<float> spotlightCutoffs;
    std::vector<Material> materialColor;

    cout << "Scene Details:" << endl;

    while (file >> type) {
        if (type == "e") {
            file >> cameraPos.x >> cameraPos.y >> cameraPos.z;
            float modeFlag;
            file >> modeFlag; // Ignored if anti-aliasing is not implemented
            cout << "Camera Position: " << cameraPos.x << ", " << cameraPos.y << ", " << cameraPos.z << endl;
        } else if (type == "a") {
            file >> ambientLight.r >> ambientLight.g >> ambientLight.b;
            float ignore; // Ignoring the 4th coordinate
            file >> ignore;
            cout << "Ambient Light: " << ambientLight.r << ", " << ambientLight.g << ", " << ambientLight.b << endl;
        } else if (type == "d") {
            vec3 dir;
            float lightType;
            file >> dir.x >> dir.y >> dir.z >> lightType;
            if (lightType == 0.0f) { // Directional Light
                lights.push_back(new DirectionalLight(dir, vec3(1.0f)));
                cout << "Directional Light: Direction(" << dir.x << ", " << dir.y << ", " << dir.z << ")" << endl;
            } else if (lightType == 1.0f) { // Spotlight
                spotlightPositions.push_back(dir); // Spotlight position will be parsed next
                cout << "Spotlight Direction: (" << dir.x << ", " << dir.y << ", " << dir.z << ")" << endl;
            }
        } else if (type == "p") {
            vec3 pos;
            float cutoff;
            file >> pos.x >> pos.y >> pos.z >> cutoff;
            spotlightCutoffs.push_back(cutoff);
            cout << "Spotlight Position: (" << pos.x << ", " << pos.y << ", " << pos.z << "), Cutoff(" << cutoff << ")" << endl;
        } else if (type == "i") {
            vec3 intensity;
            file >> intensity.r >> intensity.g >> intensity.b;
            float ignore; // Ignoring the 4th coordinate
            file >> ignore;
            if (!spotlightPositions.empty()) {
                lights.push_back(new Spotlight(spotlightPositions.back(), vec3(0, 0, -1), spotlightCutoffs.back(), intensity));
                spotlightPositions.pop_back();
                spotlightCutoffs.pop_back();
                cout << "Spotlight Intensity: " << intensity.r << ", " << intensity.g << ", " << intensity.b << endl;
            } else {
                lights.back()->intensity = intensity;
                cout << "Light Intensity: " << intensity.r << ", " << intensity.g << ", " << intensity.b << endl;
            }
        } else if (type == "o" || type == "r" || type == "t") {
            vec3 centerOrNormal;
            float radiusOrD;
            file >> centerOrNormal.x >> centerOrNormal.y >> centerOrNormal.z >> radiusOrD;
            if (type == "o") { // Normal object
                if (radiusOrD > 0) { // Sphere
                    objects.push_back(new Sphere(centerOrNormal, radiusOrD, currentMaterial, 0));
                    cout << "Sphere: Center(" << centerOrNormal.x << ", " << centerOrNormal.y << ", " << centerOrNormal.z << "), Radius(" << radiusOrD << ")" << endl;
                } else if (radiusOrD <= 0) { // Plane
                    objects.push_back(new Plane(centerOrNormal, radiusOrD, currentMaterial, 0));
                    cout << "Plane: Normal(" << centerOrNormal.x << ", " << centerOrNormal.y << ", " << centerOrNormal.z << "), d(" << radiusOrD << ")" << endl;
                }
            } else if (type == "r") { // Reflective
                if (radiusOrD > 0) {
                    objects.push_back(new Sphere(centerOrNormal, radiusOrD, Material(vec3(1.0f), 0.0f), 1));
                    cout << "Reflective Sphere: Center(" << centerOrNormal.x << ", " << centerOrNormal.y << ", " << centerOrNormal.z << "), Radius(" << radiusOrD << ")" << endl;
                } else if (radiusOrD <= 0) {
                    objects.push_back(new Plane(centerOrNormal, radiusOrD, Material(vec3(1.0f), 0.0f), 1));
                    cout << "Reflective Plane: Normal(" << centerOrNormal.x << ", " << centerOrNormal.y << ", " << centerOrNormal.z << "), d(" << radiusOrD << ")" << endl;
                }
            } else if (type == "t") { // Transparent
                if (radiusOrD > 0) {
                    objects.push_back(new Sphere(centerOrNormal, radiusOrD, Material(vec3(1.0f), 0.0f), 2));
                    cout << "Transparent Sphere: Center(" << centerOrNormal.x << ", " << centerOrNormal.y << ", " << centerOrNormal.z << "), Radius(" << radiusOrD << ")" << endl;
                }
            }
        } else if (type == "c") {
            vec3 color;
            float shininess;
            file >> color.r >> color.g >> color.b >> shininess;
            materialColor.emplace_back(color,shininess);
            cout << "Material: Color(" << color.r << ", " << color.g << ", " << color.b << "), Shininess(" << shininess << ")" << endl;
        }
    }
    for (size_t i = 0; i < objects.size(); i++)
    {
        if(i<materialColor.size()){
            objects[i]->setColor(materialColor[i].color);
        }
    }
    

    file.close();
}



void saveImage(const string& filename, const vector<vector<vec3>>& image) {
    unsigned char* data = new unsigned char[WIDTH * HEIGHT * 3];
    for (int y = 0; y < HEIGHT; ++y) {
        for (int x = 0; x < WIDTH; ++x) {
            int index = (y * WIDTH + x) * 3;
            data[index] = static_cast<unsigned char>(std::clamp(image[y][x].r, 0.0f, 1.0f) * 255);
            data[index + 1] = static_cast<unsigned char>(std::clamp(image[y][x].g, 0.0f, 1.0f) * 255);
            data[index + 2] = static_cast<unsigned char>(std::clamp(image[y][x].b, 0.0f, 1.0f) * 255);
        }
    }
    stbi_write_png(filename.c_str(), WIDTH, HEIGHT, 3, data, WIDTH * 3);
    delete[] data;
}


int main() {
    vector<Object*> objects;
    vector<Light*> lights;
    vec3 cameraPos(0.0f, 0.0f, 1.0f); // Default camera position
    vec3 ambientLight(0.0f); // Default ambient light

    parseScene(INPUT_FILE_PATH, objects, lights, cameraPos, ambientLight);

    vector<vector<vec3>> image(HEIGHT, vector<vec3>(WIDTH));

    // Screen boundaries in scene coordinates
    float left = -1.0f, right = 1.0f;
    float bottom = -1.0f, top = 1.0f;
    float screenZ = 0.0f; // Screen is on z = 0 plane
    vec3 screenCenter(0.0f, 0.0f, screenZ);

    // Camera view direction
    vec3 viewDir = normalize(screenCenter - cameraPos);
    vec3 up(0.0f, 1.0f, 0.0f);
    vec3 Right = normalize(cross(viewDir, up));
    vec3 adjustedUp = cross(Right, viewDir);

    // Ray tracing loop
    for (int y = 0; y < HEIGHT; ++y) {
        for (int x = 0; x < WIDTH; ++x) {
            // Flip the vertical coordinate (v)
            float u = left + (right - left) * (x + 0.5f) / WIDTH;
            float v = bottom + (top - bottom) * ((HEIGHT - 1 - y) + 0.5f) / HEIGHT;

            // Compute pixel position on the screen
            vec3 pixelPoint = screenCenter + u * Right + v * adjustedUp;

            // Create a ray from the camera position to the pixel
            vec3 rayDir = normalize(pixelPoint - cameraPos);
            Ray ray(cameraPos, rayDir);

            // Trace the ray and compute color
            image[y][x] = traceRay(ray, objects, lights, 0);
        }
    }

    // Save the rendered image
    saveImage("outputimage.png", image);

    // Cleanup
    for (auto object : objects) delete object;
    for (auto light : lights) delete light;

    return 0;
}